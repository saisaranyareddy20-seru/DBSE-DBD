import React, { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const NotificationContext = createContext();

export const useNotifications = () => useContext(NotificationContext);

export const NotificationProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      // Connect directly to Notification Service (bypassing stateless gateway for WS)
      const newSocket = io('http://localhost:5005');
      
      newSocket.on('connect', () => {
        newSocket.emit('join', user.id);
      });

      newSocket.on('new_notification', (data) => {
        setNotifications((prev) => [data, ...prev]);
        setUnreadCount((prev) => prev + 1);
        // Play a subtle sound or toast here if desired
      });

      setSocket(newSocket);

      return () => newSocket.close();
    }
  }, [user]);

  const clearUnread = () => setUnreadCount(0);

  return (
    <NotificationContext.Provider value={{ socket, notifications, unreadCount, clearUnread }}>
      {children}
    </NotificationContext.Provider>
  );
};
