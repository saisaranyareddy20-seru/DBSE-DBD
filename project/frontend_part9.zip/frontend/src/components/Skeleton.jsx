import React from 'react';

export const SkeletonRow = ({ cols = 4, dark = false }) => (
  <tr>
    {Array.from({ length: cols }).map((_, i) => (
      <td key={i} className="px-6 py-4">
        <div className={`h-4 rounded ${dark ? 'skeleton-dark' : 'skeleton'}`} style={{ width: `${60 + (i * 13) % 30}%` }} />
      </td>
    ))}
  </tr>
);

export const SkeletonCard = ({ dark = false, lines = 3 }) => (
  <div className={`p-6 rounded-2xl ${dark ? 'bg-gray-800' : 'bg-white'} shadow-sm`}>
    <div className={`h-5 w-1/3 mb-4 rounded ${dark ? 'skeleton-dark' : 'skeleton'}`} />
    {Array.from({ length: lines }).map((_, i) => (
      <div key={i} className={`h-3 rounded mb-2 ${dark ? 'skeleton-dark' : 'skeleton'}`} style={{ width: `${75 + (i * 7) % 20}%` }} />
    ))}
  </div>
);

export const SkeletonStat = ({ dark = false }) => (
  <div className={`p-6 rounded-2xl ${dark ? 'bg-gray-800' : 'bg-white'} shadow-sm`}>
    <div className={`h-3 w-24 rounded mb-3 ${dark ? 'skeleton-dark' : 'skeleton'}`} />
    <div className={`h-8 w-16 rounded ${dark ? 'skeleton-dark' : 'skeleton'}`} />
  </div>
);

export const EmptyState = ({ icon, title, subtitle, dark = false }) => (
  <div className="flex flex-col items-center justify-center py-16 text-center">
    <div className={`text-6xl mb-4`}>{icon}</div>
    <h3 className={`text-lg font-semibold mb-1 ${dark ? 'text-gray-200' : 'text-gray-700'}`}>{title}</h3>
    <p className={`text-sm ${dark ? 'text-gray-400' : 'text-gray-500'}`}>{subtitle}</p>
  </div>
);
