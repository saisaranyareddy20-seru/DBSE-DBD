import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useToast } from '../context/ToastContext';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { SkeletonStat } from './Skeleton';

const MONTHLY = [
  { month: 'Apr 25', expected: 680000, collected: 612000, outstanding: 68000 },
  { month: 'May 25', expected: 695000, collected: 651000, outstanding: 44000 },
  { month: 'Jun 25', expected: 710000, collected: 624000, outstanding: 86000 },
  { month: 'Jul 25', expected: 720000, collected: 698000, outstanding: 22000 },
  { month: 'Aug 25', expected: 735000, collected: 709000, outstanding: 26000 },
  { month: 'Sep 26', expected: 750000, collected: 625000, outstanding: 125000 },
];

const FinancialDashboard = ({ darkMode }) => {
  const [finance, setFinance] = useState(null);
  const [loading, setLoading] = useState(true);
  const { addToast } = useToast();

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const res = await axios.get('http://localhost:8000/api/analytics/finance');
        setFinance(res.data);
      } catch { addToast('Could not load financial data.', 'error'); }
      finally { setLoading(false); }
    };
    fetch();
  }, []);

  const card = darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const sub  = darkMode ? 'text-gray-400' : 'text-gray-500';
  const curr = MONTHLY[MONTHLY.length - 1];
  const rate = Math.round((curr.collected / curr.expected) * 100);
  const barW = (pct) => `${pct}%`;

  return (
    <div className="space-y-6">
      {/* Current Month Banner */}
      <div className="rounded-2xl overflow-hidden shadow-lg" style={{ background: 'linear-gradient(135deg, #1e1b4b 0%, #4f46e5 60%, #7c3aed 100%)' }}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-indigo-200 text-sm font-medium">Society Financial Dashboard</p>
              <h2 className="text-white text-2xl font-extrabold mt-1">September 2026</h2>
            </div>
            <div className="text-right">
              <p className="text-indigo-200 text-sm">Collection Rate</p>
              <p className="text-4xl font-extrabold text-white">{rate}%</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: 'Expected Collection', value: `₹${(curr.expected/100000).toFixed(2)}L`, color: 'text-indigo-200', bg: 'bg-white/10' },
              { label: 'Collected',           value: `₹${(curr.collected/100000).toFixed(2)}L`, color: 'text-emerald-300', bg: 'bg-emerald-500/20' },
              { label: 'Outstanding',         value: `₹${(curr.outstanding/1000).toFixed(0)}K`, color: 'text-red-300',     bg: 'bg-red-500/20' },
            ].map((s, i) => (
              <div key={i} className={`rounded-xl p-4 ${s.bg}`}>
                <p className="text-indigo-200 text-xs font-medium uppercase tracking-wide">{s.label}</p>
                <p className={`text-2xl font-extrabold mt-1 ${s.color}`}>{loading ? '—' : s.value}</p>
              </div>
            ))}
          </div>
          {/* Collection Progress Bar */}
          <div className="mt-5">
            <div className="flex justify-between text-xs text-indigo-200 mb-1.5">
              <span>Collection Progress</span>
              <span>{rate}% collected</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-3 overflow-hidden">
              <div className="h-3 rounded-full bg-gradient-to-r from-emerald-400 to-emerald-500 transition-all duration-1000"
                style={{ width: `${rate}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Collection Bar Chart */}
      <div className={`rounded-2xl border shadow-sm p-6 ${card}`}>
        <h3 className={`text-base font-semibold mb-4 ${text}`}>Monthly Collection — Last 6 Months</h3>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={MONTHLY} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#f1f5f9'} />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke={darkMode ? '#6b7280' : '#94a3b8'} />
              <YAxis tick={{ fontSize: 11 }} stroke={darkMode ? '#6b7280' : '#94a3b8'} tickFormatter={v => `₹${(v/100000).toFixed(1)}L`} />
              <Tooltip formatter={v => [`₹${Number(v).toLocaleString()}`, '']}
                contentStyle={{ background: darkMode ? '#1f2937' : '#fff', borderRadius: '12px', border: '1px solid #e2e8f0' }} />
              <Legend />
              <Bar dataKey="collected"   fill="#6366f1" radius={[6,6,0,0]} name="Collected" />
              <Bar dataKey="outstanding" fill="#ef4444" radius={[6,6,0,0]} name="Outstanding" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Monthly Progress Bars */}
      <div className={`rounded-2xl border shadow-sm p-6 ${card}`}>
        <h3 className={`text-base font-semibold mb-5 ${text}`}>Collection Rate by Month</h3>
        <div className="space-y-4">
          {MONTHLY.map((m, i) => {
            const pct = Math.round((m.collected / m.expected) * 100);
            return (
              <div key={i}>
                <div className="flex justify-between items-center mb-1.5">
                  <span className={`text-sm font-medium ${text}`}>{m.month}</span>
                  <div className="flex items-center gap-3">
                    <span className={`text-xs ${sub}`}>₹{(m.collected/100000).toFixed(2)}L / ₹{(m.expected/100000).toFixed(2)}L</span>
                    <span className={`text-xs font-bold ${pct >= 90 ? 'text-emerald-600' : pct >= 80 ? 'text-blue-600' : 'text-amber-600'}`}>{pct}%</span>
                  </div>
                </div>
                <div className={`w-full h-2.5 rounded-full ${darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
                  <div className={`h-2.5 rounded-full transition-all duration-700 ${pct >= 90 ? 'bg-emerald-500' : pct >= 80 ? 'bg-indigo-500' : 'bg-amber-500'}`}
                    style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Expected YTD', value: `₹${(MONTHLY.reduce((s,m) => s+m.expected,0)/100000).toFixed(1)}L`, icon: '📊', color: 'text-indigo-600' },
          { label: 'Total Collected YTD', value: `₹${(MONTHLY.reduce((s,m) => s+m.collected,0)/100000).toFixed(1)}L`, icon: '✅', color: 'text-emerald-600' },
          { label: 'Total Outstanding', value: `₹${(MONTHLY.reduce((s,m) => s+m.outstanding,0)/1000).toFixed(0)}K`, icon: '⚠️', color: 'text-red-600' },
          { label: 'Avg Collection Rate', value: `${Math.round(MONTHLY.reduce((s,m) => s+(m.collected/m.expected),0)/MONTHLY.length*100)}%`, icon: '📈', color: 'text-blue-600' },
        ].map((s, i) => (
          <div key={i} className={`card-hover rounded-2xl p-5 border shadow-sm ${card}`}>
            <div className="text-3xl mb-2">{s.icon}</div>
            <p className={`text-xs font-medium uppercase tracking-wide ${sub}`}>{s.label}</p>
            <p className={`text-xl font-extrabold mt-1 ${darkMode ? 'text-white' : s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FinancialDashboard;
