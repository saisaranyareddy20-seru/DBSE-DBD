import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useToast } from '../context/ToastContext';
import { AlertCircle, Flame, Filter } from 'lucide-react';
import { SkeletonRow, EmptyState } from './Skeleton';

const PRIORITY = {
  CRITICAL: { label: '🔴 URGENT',  cls: 'chip-urgent',  dot: 'bg-red-500 pulse-dot', order: 1 },
  HIGH:     { label: '🟠 HIGH',    cls: 'chip-high',    dot: 'bg-orange-400', order: 2 },
  MEDIUM:   { label: '🟡 MEDIUM',  cls: 'chip-medium',  dot: 'bg-yellow-400', order: 3 },
  LOW:      { label: '🟢 LOW',     cls: 'chip-low',     dot: 'bg-green-400',  order: 4 },
};

const STATUS = {
  OPEN:        { label: 'Open',        cls: 'chip-open' },
  IN_PROGRESS: { label: 'In Progress', cls: 'chip-in_progress' },
  RESOLVED:    { label: 'Resolved',    cls: 'chip-resolved' },
  REJECTED:    { label: 'Rejected',    cls: 'chip-overdue' },
};

const ComplaintList = ({ darkMode }) => {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL');
  const { addToast } = useToast();

  useEffect(() => { fetchComplaints(); }, []);

  const fetchComplaints = async () => {
    setLoading(true);
    try {
      const res = await axios.get('http://localhost:8000/api/complaints');
      const sorted = (res.data || []).sort((a, b) =>
        (PRIORITY[a.priority]?.order || 5) - (PRIORITY[b.priority]?.order || 5)
      );
      setComplaints(sorted);
    } catch {
      addToast('Failed to load complaints.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const card = darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const sub  = darkMode ? 'text-gray-400' : 'text-gray-500';
  const th   = darkMode ? 'bg-gray-700/50 text-gray-300' : 'bg-slate-50 text-gray-500';
  const td   = darkMode ? 'text-gray-300 border-gray-700' : 'text-gray-700 border-gray-100';

  const filters = ['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
  const filtered = filter === 'ALL' ? complaints : complaints.filter(c => c.priority === filter);

  const counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
  complaints.forEach(c => { if (counts[c.priority] !== undefined) counts[c.priority]++; });

  return (
    <div className="space-y-6">
      {/* Priority Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Object.entries(PRIORITY).map(([key, val]) => (
          <button key={key} onClick={() => setFilter(key === filter ? 'ALL' : key)}
            className={`card-hover rounded-2xl p-4 border shadow-sm text-left transition-all ${card} ${filter === key ? 'ring-2 ring-indigo-500' : ''}`}>
            <div className={`w-3 h-3 rounded-full mb-3 ${val.dot}`} />
            <p className={`text-xs font-medium uppercase tracking-wide ${sub}`}>{key}</p>
            <p className={`text-3xl font-bold mt-1 ${text}`}>{counts[key]}</p>
          </button>
        ))}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 flex-wrap">
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all border ${
              filter === f
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : darkMode ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}>
            {f === 'ALL' ? `All (${complaints.length})` : `${f} (${counts[f]})`}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className={`rounded-2xl border shadow-sm overflow-hidden ${card}`}>
        <div className={`px-6 py-4 border-b ${darkMode ? 'border-gray-700' : 'border-gray-100'} flex items-center gap-2`}>
          <Flame className="w-4 h-4 text-orange-500" />
          <h3 className={`text-base font-semibold ${text}`}>Complaints — Priority View</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className={th}>
                {['Priority', 'Title', 'Category', 'Flat', 'Status', 'SLA'].map(h => (
                  <th key={h} className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className={`divide-y ${darkMode ? 'divide-gray-700' : 'divide-gray-100'}`}>
              {loading ? (
                Array.from({ length: 8 }).map((_, i) => <SkeletonRow key={i} cols={6} dark={darkMode} />)
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6}><EmptyState icon="📋" title="No complaints found" subtitle="All quiet — no issues reported" dark={darkMode} /></td></tr>
              ) : (
                filtered.slice(0, 30).map(c => {
                  const p = PRIORITY[c.priority] || PRIORITY.LOW;
                  const s = STATUS[c.status] || STATUS.OPEN;
                  return (
                    <tr key={c.id} className={`transition-colors ${darkMode ? 'hover:bg-gray-700/40' : 'hover:bg-slate-50'}`}>
                      <td className="px-6 py-3.5">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${p.cls}`}>
                          <span className={`w-2 h-2 rounded-full ${p.dot}`} />
                          {p.label}
                        </span>
                      </td>
                      <td className={`px-6 py-3.5 text-sm font-medium max-w-xs ${text}`}>
                        <div>{c.title}</div>
                        {c.sla_breached ? <span className="text-xs text-red-500 font-semibold">⚠ SLA Breached</span> : null}
                      </td>
                      <td className={`px-6 py-3.5 text-xs font-medium ${sub}`}>{c.category}</td>
                      <td className={`px-6 py-3.5 text-sm font-semibold ${darkMode ? 'text-indigo-300' : 'text-indigo-600'}`}>{c.flat_number || c.flat_id}</td>
                      <td className="px-6 py-3.5">
                        <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-semibold ${s.cls}`}>{s.label}</span>
                      </td>
                      <td className={`px-6 py-3.5 text-xs ${sub}`}>
                        {new Date(c.created_at).toLocaleDateString('en-IN')}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ComplaintList;
