import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { useToast } from '../context/ToastContext';
import {
  Bell, CreditCard, Users, AlertCircle, LogOut, Calendar, Car,
  Activity, Moon, Sun, Search, Star, Building2, ChevronRight, X,
  Shield, Map, TrendingUp, Home
} from 'lucide-react';
import BillingList from '../components/BillingList';
import ComplaintList from '../components/ComplaintList';
import VisitorList from '../components/VisitorList';
import FacilityBooking from '../components/FacilityBooking';
import VehicleManagement from '../components/VehicleManagement';
import SystemHealth from '../components/SystemHealth';
import AnalyticsDashboard from '../components/AnalyticsDashboard';
import FinancialDashboard from '../components/FinancialDashboard';
import CommunityHub from '../components/CommunityHub';
import SecurityDashboard from '../components/SecurityDashboard';
import SocietyMap from '../components/SocietyMap';
import axios from 'axios';

const ALL_NAV = [
  { id: 'billing',    icon: CreditCard,  label: 'Billing',         roles: ['ADMIN','RESIDENT'] },
  { id: 'complaints', icon: AlertCircle, label: 'Complaints',       roles: ['ADMIN','RESIDENT'] },
  { id: 'visitors',   icon: Users,       label: 'Visitors & QR',    roles: ['ADMIN'] },
  { id: 'facilities', icon: Calendar,    label: 'Facilities',       roles: ['ADMIN','RESIDENT'] },
  { id: 'vehicles',   icon: Car,         label: 'Parking',          roles: ['ADMIN','RESIDENT'] },
  { id: 'community',  icon: Star,        label: 'Community',        roles: ['ADMIN','RESIDENT'] },
  { id: 'map',        icon: Map,         label: 'Society Map',      roles: ['ADMIN','RESIDENT'] },
  { id: 'analytics',  icon: Activity,    label: 'Analytics',        roles: ['ADMIN'] },
  { id: 'financial',  icon: TrendingUp,  label: 'Financials',       roles: ['ADMIN'] },
  { id: 'security',   icon: Shield,      label: 'Security',         roles: ['ADMIN'] },
  { id: 'health',     icon: Activity,    label: 'System Health',    roles: ['ADMIN'] },
];

const TAB_LABELS = {
  billing: 'Billing & Payments', complaints: 'Complaints', visitors: 'Visitors & QR',
  facilities: 'Facilities', vehicles: 'Parking Overview', community: 'Community Hub',
  map: 'Society Map', analytics: 'Analytics', financial: 'Financial Dashboard',
  security: 'Security Dashboard', health: 'System Health',
};

const SearchPanel = ({ results, query, darkMode, loading, onClose }) => {
  const card = darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const sub  = darkMode ? 'text-gray-400' : 'text-gray-500';
  const ICONS = { residents:'👤', complaints:'📋', vehicles:'🚗', visitors:'🚪', providers:'🔧', events:'🎉', facilities:'🏢' };

  const total = results ? Object.values(results).reduce((s, v) => s + (Array.isArray(v) ? v.length : 0), 0) : 0;
  return (
    <div className={`rounded-3xl border shadow-2xl overflow-hidden ${card}`}>
      <div className={`px-6 py-4 border-b flex justify-between items-center ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>
        <div>
          <h3 className={`text-sm font-bold ${text}`}>Search results for "{query}"</h3>
          <p className={`text-xs ${sub}`}>{loading ? 'Searching...' : `${total} results across all features`}</p>
        </div>
        <button onClick={onClose} className={`${sub} hover:text-red-500 transition-colors p-1`}><X className="w-4 h-4" /></button>
      </div>
      {loading ? (
        <div className="px-6 py-10 text-center">
          <div className="animate-spin w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full mx-auto mb-3" />
          <p className={`text-sm ${sub}`}>Searching all data...</p>
        </div>
      ) : total === 0 ? (
        <div className="px-6 py-10 text-center">
          <div className="text-5xl mb-3">🔍</div>
          <p className={`font-semibold ${text}`}>No results found</p>
          <p className={`text-sm ${sub} mt-1`}>Try a different search term</p>
        </div>
      ) : (
        <div className="p-4 space-y-4 max-h-[60vh] overflow-y-auto">
          {results && Object.entries(results).map(([key, items]) => {
            if (!Array.isArray(items) || items.length === 0) return null;
            return (
              <div key={key}>
                <p className={`text-xs font-bold uppercase tracking-widest mb-2 ${sub}`}>
                  {ICONS[key] || '📌'} {key.charAt(0).toUpperCase() + key.slice(1)}
                </p>
                <div className="space-y-1">
                  {items.map((item, i) => (
                    <div key={i} className={`flex items-center justify-between px-4 py-2.5 rounded-xl transition-colors ${darkMode ? 'bg-gray-700/60 hover:bg-gray-700' : 'bg-gray-50 hover:bg-indigo-50'}`}>
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-lg shrink-0">{ICONS[key] || '📌'}</span>
                        <div className="min-w-0">
                          <p className={`text-sm font-semibold truncate ${text}`}>
                            {item.name || item.title || item.vehicle_number || item.category || item.flat_number || '—'}
                          </p>
                          <p className={`text-xs ${sub} truncate`}>
                            {item.phone || item.description || item.status || item.purpose || ''}
                          </p>
                        </div>
                      </div>
                      {item.priority && (
                        <span className={`text-xs px-2 py-0.5 rounded-full shrink-0 chip-${item.priority?.toLowerCase()}`}>{item.priority}</span>
                      )}
                      {item.rating && (
                        <span className="text-xs text-amber-600 font-bold shrink-0">★ {item.rating}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

const Dashboard = () => {
  const { user, logout } = useAuth();
  const { notifications, unreadCount, clearUnread } = useNotifications();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('billing');
  const [showNotifications, setShowNotifications] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [searching, setSearching] = useState(false);

  if (!user) return null;

  const role = user.role || user.role_name || 'RESIDENT';
  const navItems = ALL_NAV.filter(n => n.roles.includes(role));
  const initials = user.username?.substring(0, 2).toUpperCase() || 'US';

  const toggleDark = () => {
    setDarkMode(d => !d);
    document.documentElement.classList.toggle('dark');
  };

  const handleSearch = async (e) => {
    if (e.key !== 'Enter') return;
    const q = searchQuery.trim();
    if (!q) { setSearchResults(null); return; }
    setSearching(true);
    setSearchResults({});
    try {
      // Call our enhanced search
      const res = await axios.get(`http://localhost:8000/api/search?q=${encodeURIComponent(q)}`);
      setSearchResults(res.data);
    } catch {
      addToast('Search failed. Please try again.', 'error');
      setSearchResults(null);
    } finally { setSearching(false); }
  };

  const bg   = darkMode ? 'bg-gray-900' : 'bg-slate-100/80';
  const hdr  = darkMode ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-100';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const sub  = darkMode ? 'text-gray-400' : 'text-gray-500';

  return (
    <div className={`min-h-screen flex ${bg}`}>
      {/* ── Sidebar ── */}
      <div className="w-64 flex-shrink-0 flex flex-col shadow-xl" style={{ background: darkMode ? '#0f0e17' : '#1e1b4b' }}>
        {/* Logo */}
        <div className="px-5 py-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg" style={{ background: 'linear-gradient(135deg,#818cf8,#4f46e5)' }}>
              <Home className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-white font-extrabold text-base tracking-wide">RESIDENT360</p>
              <p className="text-indigo-300 text-xs font-medium">{role} Portal</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {navItems.map(item => {
            const active = activeTab === item.id;
            return (
              <button key={item.id} onClick={() => { setActiveTab(item.id); setSearchResults(null); setSearchQuery(''); }}
                className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 group ${
                  active
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/50'
                    : 'text-indigo-200/80 hover:bg-white/10 hover:text-white'
                }`}>
                <span className="flex items-center gap-3">
                  <item.icon className={`w-4 h-4 ${active ? 'text-white' : 'text-indigo-300 group-hover:text-white'}`} />
                  {item.label}
                </span>
                {active && <ChevronRight className="w-3.5 h-3.5 opacity-70" />}
              </button>
            );
          })}
        </nav>

        {/* User Footer */}
        <div className="px-3 py-4 border-t border-white/10">
          <div className="flex items-center gap-3 px-2 mb-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-extrabold text-white shrink-0 shadow-md"
              style={{ background: 'linear-gradient(135deg,#a78bfa,#6366f1)' }}>
              {initials}
            </div>
            <div className="min-w-0">
              <p className="text-white text-xs font-bold truncate">{user.username}</p>
              <p className="text-indigo-300 text-xs truncate">{role}</p>
            </div>
          </div>
          <button onClick={() => { logout(); navigate('/login'); }}
            className="w-full flex items-center gap-2 px-4 py-2 rounded-xl text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all text-sm font-semibold">
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className={`border-b px-6 py-3.5 flex items-center justify-between gap-4 shrink-0 backdrop-blur-sm ${hdr}`}>
          <div className="flex items-center gap-4 min-w-0">
            <div>
              <h1 className={`text-lg font-extrabold ${text}`}>{TAB_LABELS[activeTab]}</h1>
            </div>
            {/* Global Search */}
            <div className={`flex items-center gap-2 w-72 px-3.5 py-2 rounded-2xl border text-sm transition-all focus-within:ring-2 focus-within:ring-indigo-400 ${
              darkMode ? 'bg-gray-700/80 border-gray-600' : 'bg-gray-50/80 border-gray-200'
            }`}>
              <Search className={`w-4 h-4 shrink-0 ${searching ? 'text-indigo-500 animate-pulse' : sub}`} />
              <input type="text" placeholder="Search anything... (press Enter)"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={handleSearch}
                className={`bg-transparent focus:outline-none w-full text-sm ${darkMode ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'}`}
              />
              {searchQuery && (
                <button onClick={() => { setSearchQuery(''); setSearchResults(null); }} className={`${sub} hover:text-red-500`}>
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Dark mode */}
            <button onClick={toggleDark}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all hover:scale-110 ${darkMode ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Bell */}
            <div className="relative">
              <button onClick={() => { setShowNotifications(n => !n); clearUnread(); }}
                className={`w-9 h-9 rounded-xl flex items-center justify-center relative transition-all hover:scale-110 ${darkMode ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold animate-pulse">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>
              {showNotifications && (
                <div className={`absolute right-0 top-12 w-80 rounded-2xl border shadow-2xl z-50 overflow-hidden ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'}`}>
                  <div className={`px-4 py-3 border-b flex justify-between items-center ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>
                    <span className={`text-sm font-bold ${text}`}>Notifications</span>
                    <button onClick={() => setShowNotifications(false)} className={sub}><X className="w-4 h-4" /></button>
                  </div>
                  <div className="max-h-72 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="px-4 py-8 text-center">
                        <Bell className={`w-8 h-8 mx-auto mb-2 ${sub}`} />
                        <p className={`text-sm ${sub}`}>You're all caught up!</p>
                      </div>
                    ) : notifications.map((n, i) => (
                      <div key={i} className={`px-4 py-3 border-b text-sm flex gap-3 ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>
                        <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                        <div>
                          <p className={`font-semibold ${text}`}>{n.type}</p>
                          <p className={`text-xs mt-0.5 ${sub}`}>{n.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Avatar */}
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-extrabold text-white shadow-md"
              style={{ background: 'linear-gradient(135deg,#a78bfa,#6366f1)' }}>
              {initials}
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {searchResults !== null ? (
            <SearchPanel results={searchResults} query={searchQuery} darkMode={darkMode} loading={searching}
              onClose={() => { setSearchResults(null); setSearchQuery(''); }} />
          ) : (
            <>
              {activeTab === 'billing'    && <BillingList darkMode={darkMode} />}
              {activeTab === 'complaints' && <ComplaintList darkMode={darkMode} />}
              {activeTab === 'visitors'   && <VisitorList darkMode={darkMode} />}
              {activeTab === 'facilities' && <FacilityBooking darkMode={darkMode} />}
              {activeTab === 'vehicles'   && <VehicleManagement darkMode={darkMode} />}
              {activeTab === 'community'  && <CommunityHub darkMode={darkMode} />}
              {activeTab === 'map'        && <SocietyMap darkMode={darkMode} />}
              {activeTab === 'analytics'  && <AnalyticsDashboard darkMode={darkMode} />}
              {activeTab === 'financial'  && <FinancialDashboard darkMode={darkMode} />}
              {activeTab === 'security'   && <SecurityDashboard darkMode={darkMode} />}
              {activeTab === 'health'     && <SystemHealth darkMode={darkMode} />}
            </>
          )}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
