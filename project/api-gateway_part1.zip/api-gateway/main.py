import os
import jwt
import httpx
import time
import mysql.connector
from fastapi import FastAPI, Request, HTTPException, Response, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="Society Management API Gateway")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

JWT_SECRET = os.getenv("JWT_SECRET", "supersecretjwtkey_for_academic_project_123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "root")
DB_NAME = os.getenv("DB_NAME", "society_management")

SERVICES = {
    "auth": "http://localhost:5001",
    "billing": "http://localhost:5002",
    "visitors": "http://localhost:5003",
    "complaints": "http://localhost:5004",
    "notifications": "http://localhost:5005",
    "facilities": "http://localhost:5006",
    "vehicles": "http://localhost:5006",
    "analytics": "http://localhost:5007",
}

PUBLIC_ROUTES = [
    "/api/auth/login",
    "/api/auth/register",
    "/health"
]

@app.get("/api/search")
async def global_search(q: str, request: Request):
    headers = {"Authorization": request.headers.get("Authorization", "")}
    q_lower = q.lower()
    results = {}

    async with httpx.AsyncClient(timeout=5.0) as client_temp:
        # Search complaints
        try:
            r = await client_temp.get("http://localhost:5004/api/complaints", headers=headers)
            if r.status_code == 200:
                results['complaints'] = [c for c in r.json() if
                    q_lower in c.get('title','').lower() or
                    q_lower in c.get('description','').lower() or
                    q_lower in c.get('category','').lower() or
                    q_lower in str(c.get('flat_number','')).lower()]
        except: pass

        # Search vehicles
        try:
            r = await client_temp.get("http://localhost:5006/api/vehicles", headers=headers)
            if r.status_code == 200:
                results['vehicles'] = [v for v in r.json() if
                    q_lower in v.get('vehicle_number','').lower() or
                    q_lower in v.get('resident_name','').lower() or
                    q_lower in v.get('flat_number','').lower()]
        except: pass

        # Search visitors
        try:
            r = await client_temp.get("http://localhost:5003/api/visitors", headers=headers)
            if r.status_code == 200:
                results['visitors'] = [v for v in r.json() if
                    q_lower in v.get('name','').lower() or
                    q_lower in v.get('purpose','').lower() or
                    q_lower in v.get('flat_number','').lower()]
        except: pass

        # Search analytics (providers + events)
        try:
            pr = await client_temp.get("http://localhost:5007/api/analytics/providers", headers=headers)
            if pr.status_code == 200:
                results['providers'] = [p for p in pr.json() if
                    q_lower in p.get('name','').lower() or
                    q_lower in p.get('category','').lower() or
                    q_lower in p.get('phone','').lower()]
        except: pass

        try:
            er = await client_temp.get("http://localhost:5007/api/analytics/events", headers=headers)
            if er.status_code == 200:
                results['events'] = [e for e in er.json() if
                    q_lower in e.get('title','').lower() or
                    q_lower in e.get('description','').lower() or
                    q_lower in e.get('location','').lower()]
        except: pass

        # Search facilities
        try:
            fr = await client_temp.get("http://localhost:5006/api/facilities", headers=headers)
            if fr.status_code == 200:
                results['facilities'] = [f for f in fr.json() if
                    q_lower in f.get('name','').lower() or
                    q_lower in str(f.get('description','')).lower()]
        except: pass

    return results


client = httpx.AsyncClient()

CACHE = {}
CACHE_TTL = 30 # seconds

def write_audit_log(user_id: int, action: str, details: str, ip_address: str):
    try:
        conn = mysql.connector.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (%s, %s, %s, %s)",
            (user_id, action, details, ip_address)
        )
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Audit log failed: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    await client.aclose()

@app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
async def gateway(request: Request, path: str, background_tasks: BackgroundTasks):
    if path == "health":
        health_status = {"status": "UP", "gateway": "UP", "services": {}}
        async with httpx.AsyncClient() as client_temp:
            for name, url in SERVICES.items():
                if name in health_status["services"]:
                    continue
                try:
                    res = await client_temp.get(f"{url}/health", timeout=2.0)
                    health_status["services"][name] = "UP" if res.status_code == 200 else "DOWN"
                except:
                    health_status["services"][name] = "DOWN"
                    health_status["status"] = "DEGRADED"
        return health_status
        
    full_path = f"/{path}"
    
    # 1. JWT Validation
    user_payload = None
    if full_path not in PUBLIC_ROUTES and request.method != "OPTIONS":
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Unauthorized: Missing token")
            
        token = auth_header.split(" ")[1]
        try:
            user_payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Unauthorized: Token expired")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Unauthorized: Invalid token")

    # Audit Logging for mutating requests
    if request.method in ["POST", "PUT", "PATCH", "DELETE"] and user_payload:
        background_tasks.add_task(
            write_audit_log, 
            user_payload.get("userId"), 
            f"{request.method} {full_path}", 
            "API Gateway proxied request", 
            request.client.host
        )

    # 2. Route resolution
    path_parts = path.split("/")
    if len(path_parts) < 2 or path_parts[0] != "api":
        raise HTTPException(status_code=404, detail="Not Found")
        
    service_name = path_parts[1]
    if service_name not in SERVICES:
        raise HTTPException(status_code=404, detail="Service not found")

    target_host = SERVICES[service_name]
    target_url = f"{target_host}{full_path}"
    
    if request.url.query:
        target_url += f"?{request.url.query}"
        
    # --- CACHE CHECK ---
    cache_key = None
    if request.method == "GET" and user_payload:
        cache_key = f"{user_payload.get('userId')}_{target_url}"
        cached_entry = CACHE.get(cache_key)
        if cached_entry and time.time() - cached_entry['timestamp'] < CACHE_TTL:
            print(f"[CACHE HIT] Returning cached response for {full_path}")
            return Response(
                content=cached_entry['content'],
                status_code=200,
                headers={"X-Cache": "HIT", "Content-Type": "application/json"}
            )

    # 3. Forward the request
    headers = dict(request.headers)
    headers.pop("host", None) 
    if user_payload:
        headers["x-user-id"] = str(user_payload.get("userId"))
        headers["x-user-role"] = user_payload.get("role")

    body = await request.body()

    try:
        response = await client.request(
            method=request.method,
            url=target_url,
            headers=headers,
            content=body,
            timeout=10.0
        )
        
        # --- SAVE TO CACHE ---
        if request.method == "GET" and response.status_code == 200 and cache_key:
            print(f"[CACHE MISS] Saving response to cache for {full_path}")
            CACHE[cache_key] = {
                'content': response.content,
                'timestamp': time.time()
            }
            
        response_headers = dict(response.headers)
        response_headers.pop("content-length", None)
        response_headers.pop("content-encoding", None)
        response_headers["X-Cache"] = "MISS"
        
        return Response(
            content=response.content,
            status_code=response.status_code,
            headers=response_headers
        )
    except httpx.RequestError as e:
        raise HTTPException(status_code=503, detail=f"Service unavailable: {str(e)}")
