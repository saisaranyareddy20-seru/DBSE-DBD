const express = require('express');
const router = express.Router();
const { getFacilities, getBookings, bookFacility, getVehicles, registerVehicle } = require('../controllers/facilityController');

router.get('/facilities', getFacilities);
router.get('/bookings', getBookings);
router.post('/bookings', bookFacility);

router.get('/vehicles', getVehicles);
router.post('/vehicles', registerVehicle);

module.exports = router;
